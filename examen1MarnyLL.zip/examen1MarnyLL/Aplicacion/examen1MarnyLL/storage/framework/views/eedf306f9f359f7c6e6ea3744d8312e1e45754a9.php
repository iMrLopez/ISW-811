<?php $__env->startSection('contenido'); ?>
<!--Mensaje de confirmación-->
<?php if(Session::has('info')): ?>
<div class="row">
  <div class="col-md-12">
    <p class="alert alert-info"><?php echo e(Session::get('info')); ?></p>
  </div>
</div>
<?php endif; ?>
<div class="row">
  <div class="col-lg-12">
    <h2>Lista de Helados</h2>
  </div>
</div>
<div class="row">
  <div class="col-3">
    <div class="list-group">
      <!--Lista de características-->
      <?php $__currentLoopData = $caracteristicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a  href="<?php echo e($tipo->id); ?>" class="list-group-item list-group-item-action" ><?php echo e($tipo->nombre); ?></a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <!--Lista de características-->
    </div>
    <hr>
    <p>
      <!--Extra precio maximo de todos los helados-->
      <b>Precio maximo: <?php echo e($precioMax); ?></b>
    </p>
  </div>
  <div class="col-9">
    <div class="row">
      <!--Lista de helados-->
      <?php $__currentLoopData = $helados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $helado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col">
        <div class="card" style="width: 18rem;">
          <div class="card-body">
            <div class="d-flex w-100 justify-content-between">
              <h5 class="card-title"><?php echo e($helado['nombre']); ?><br/></h5>
              <!--Cantidad de votos registrados para el helado-->
              <small><b> <?php echo e(count($helado->votos)); ?> voto(s) </b></small>
            </div>
            <div class=" justify-content-between" role="group" aria-label="Basic example">
              Votar:
              <!--Votar 1 punto-->
              <a class="btn btn-info" href="<?php echo e(route('helado.votar', ['helado' => $helado->id,'voto'=>'1'])); ?>">+1</a>
              <!--Votar 2 puntos-->
              <a class="btn btn-info" href="<?php echo e(route('helado.votar', ['helado' => $helado->id,'voto'=>'3'])); ?>">+3</a>
            </div>
            <hr>
            <p class="card-text">
              <b>Precio: </b><?php echo e($helado['precioUnitario']); ?>

            </p>
            <a class="btn btn-success" href="<?php echo e(route('helado.editar', ['helado' => $helado])); ?>">Editar</a>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <!--Lista de helados-->
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>