<?php $__env->startSection('contenido'); ?>
<!--Mensajes de error de la validación-->
<?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row">
  <div class="col-md-12">

    <form action="<?php echo e(route('helado.update')); ?>" method="post">
      <br/><br/>
      <div class="form-group">
        <label>Nombre</label>
        <input type="text" class="form-control" name="nombre" id="nombre" value="<?php echo e($helado->nombre); ?>">
      </div>
      <div class="form-group">
        <label >Detalle</label>
        <textarea class="form-control" name="detalle"><?php echo e($helado->detalle); ?></textarea>
      </div>
      <div class="form-group">
        <label>Precio Unitario</label>
        <input
        type="number"
        class="form-control"
        name="precioUnitario"
        value="<?php echo e($helado->precioUnitario); ?>">
      </div>

      <div class="form-group">
        <!--Lista de caracteristicas-->
        <?php $__currentLoopData = $caracteristicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caracteristica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-check">
          <input
          class="form-check-input" type="checkbox"
          name="caracteristicas[]"
          value="<?php echo e($caracteristica->id); ?>"
          <?php echo e($helado->caracteristicas->contains($caracteristica->id) ? 'checked' : ''); ?>

          />
          <label class="form-check-label"><?php echo e($caracteristica->nombre); ?></label>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!--Lista de caracteristicas-->
      </div>
      <?php echo csrf_field(); ?>
      <!--Identificador del helado-->
      <input type="hidden" name="id" value="<?php echo e($helado->id); ?>">
      <button type="submit" class="btn btn-success">Guardar</button>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>