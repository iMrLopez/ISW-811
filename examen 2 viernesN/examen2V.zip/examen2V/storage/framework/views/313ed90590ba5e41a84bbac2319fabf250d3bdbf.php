<?php $__env->startSection('titulo', 'Acerca de'); ?>
<?php $__env->startSection('contenido'); ?>
<div class="jumbotron">
  <h1 class="display-3">Acerca de</h1>
  <p class="lead">ISW-811 Aplicaciones Web Utilizado Software Libre</p>
  <hr class="my-4">
  <p>II Cuatrimestre 2018</p>
  <p>Universidad Técnica Nacional</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>