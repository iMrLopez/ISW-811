<?php $__env->startSection('contenido'); ?>

<div class="row">
<div class="col-lg-12">
<h2>Lista de Sushis</h2>
</div>
</div>
<div class="row">
  <div class="col-3">
    <div class="list-group">
        <?php $__currentLoopData = $contenidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a  href="<?php echo e(route('sushi.contenido',['id'=> $cont->id])); ?>"
            class="list-group-item list-group-item-action" >
            <?php echo e($cont->nombre); ?>

          </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <hr>
      <p>
        <b>Precio menor: </b><?php echo e($listado->min('precio')); ?>

      </p>
  </div>
  <div class="col-9">
    <div class="row">
      <?php $__currentLoopData = $listado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $elemento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col">
        <div class="card" style="width: 18rem;">
          <div class="card-body">
            <h5 class="card-title"><?php echo e($elemento->nombre); ?></h5>
            <p class="card-text">
              <b>Precio: </b><?php echo e($elemento->precio); ?>

            </p>
            <a class="btn btn-success" href="<?php echo e(route('sushi.editar', ['id' => $elemento->id])); ?>">Editar</a>

            <hr>
            <p class="card-text">
              <b>Cantidad de puntuaciones: </b><?php echo e(count($elemento->puntos)); ?>

            </p>
            <div class="btn-group" role="group" aria-label="Basic example">
              <b>Puntuar:</b>
              <a class="btn btn-info" href="<?php echo e(route('sushi.puntuar', ['id' => $elemento->id,'cantidad' =>1])); ?>">+1</a>
              <a class="btn btn-info" href="<?php echo e(route('sushi.puntuar', ['id' => $elemento->id,'cantidad' =>2])); ?>">+2</a>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>