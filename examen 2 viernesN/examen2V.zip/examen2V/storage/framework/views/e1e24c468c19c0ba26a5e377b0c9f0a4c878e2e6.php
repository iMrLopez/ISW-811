<?php $__env->startSection('contenido'); ?>

<?php if(Session::has('info')): ?>
        <div class="row">
            <div class="col-md-12">
                <p class="alert alert-info"><?php echo e(Session::get('info')); ?></p>
            </div>
        </div>
<?php endif; ?>
<div class="row">
        <div class="col-md-12">
            <a href="<?php echo e(route('admin.create')); ?>" class="btn btn-info">Nuevo</a>
        </div>
</div>
<br>
<table class="table table-hover">
  <thead>
    <tr class="table-info">
      <th scope="col">Nombre</th>
      <th scope="col">Editar</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $razaPerros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($rp->nombre); ?></th>
      <td><a href="<?php echo e(route('admin.edit',['id'=>$rp->id])); ?>">Editar</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>