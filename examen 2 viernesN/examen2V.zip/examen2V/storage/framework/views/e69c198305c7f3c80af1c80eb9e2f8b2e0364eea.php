<?php $__env->startSection('contenido'); ?>

<div class="row">
<div class="col-lg-12">
<h2>Lista de Helados</h2>
</div>
</div>
<div class="row">
  <div class="col-3">
    <div class="list-group">
        <?php $__currentLoopData = $caracteristicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a  href="<?php echo e(route('helado.caracteristica',['id'=> $cat->id])); ?>"
            class="list-group-item list-group-item-action" >
            <?php echo e($cat->nombre); ?>

          </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <hr>
      <p>
        <b>Precio maximo: </b><?php echo e($listado->max('precioUnitario')); ?>

      </p>
  </div>
  <div class="col-9">
    <div class="row">
      <?php $__currentLoopData = $listado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $elemento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col">
        <div class="card" style="width: 18rem;">
          <div class="card-body">
            <div class="d-flex w-100 justify-content-between">
              <h5 class="card-title"><?php echo e($elemento->nombre); ?></h5>
              <small><b> <?php echo e(count($elemento->votos)); ?> voto(s) </b></small>
            </div>
            <div class=" justify-content-between" role="group" aria-label="Basic example">
              Votar:
              <a class="btn btn-info" href="<?php echo e(route('helado.votar', ['id' => $elemento->id,'puntos' =>1])); ?>">+1</a>
              <a class="btn btn-info" href="<?php echo e(route('helado.votar', ['id' => $elemento->id,'puntos' =>3])); ?>">+3</a>
            </div>
              <hr>
            <p class="card-text">
              <b>Precio: </b><?php echo e($elemento->precioUnitario); ?>

            </p>
            <a class="btn btn-success" href="<?php echo e(route('helado.editar', ['id' => $elemento->id])); ?>">Editar</a>

          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>