<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Restaurantes</title>
      <script type="text/javascript" src="<?php echo e(URL::to('js/jquery-3.3.1.slim.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL::to('js/bootstrap.min.js')); ?>" ></script>
    <link rel="stylesheet" href="<?php echo e(URL::to('css/bootstrap.min.css')); ?>" />
</head>
<body>
<?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
    <?php echo $__env->yieldContent('contenido'); ?>
</div>
<div class="navbar navbar-expand-lg navbar-dark bg-dark">
    Nombre Completo Estudiante
</div>
</body>
</html>
