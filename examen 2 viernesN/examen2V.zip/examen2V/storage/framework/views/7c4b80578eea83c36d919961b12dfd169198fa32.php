<?php $__env->startSection('titulo','Lista de VideoJuegos'); ?>
<?php $__env->startSection('contenido'); ?>

<br>
<div class="row">
  <ul class="list-group">
      <li class="list-group-item d-flex justify-content-between align-items-center active">
    Lista de Cantidad de Razas de Perros por Tamaño
    </li>
    <?php $__currentLoopData = $tamanos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li class="list-group-item d-flex justify-content-between align-items-center">
      <?php echo e($tam->nombre); ?>

        <span class="badge badge-primary badge-pill">
          <?php echo e(count($tam->razaperros )); ?></span>
      </li>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>