<?php if(Session::has('info')): ?>
      <div class="row">
          <div class="col-md-12">
              <p class="alert alert-info"><?php echo e(Session::get('info')); ?></p>
          </div>
      </div>
  <?php endif; ?>
