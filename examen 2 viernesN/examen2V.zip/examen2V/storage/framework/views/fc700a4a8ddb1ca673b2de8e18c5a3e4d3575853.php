<?php $__env->startSection('contenido'); ?>
<?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('admin.create')); ?>" method="post">
              <br/><br/>
              <div class="form-group">
                  <label for="nombre">Nombre</label>
                  <input
                  type="text"
                  class="form-control"
                  id="nombre"
                  name="nombre">
              </div>
              <div class="form-group">
                  <label for="content">Descripción</label>
                  <textarea
                  class="form-control"
                  id="descripcion"
                  name="descripcion"></textarea>
              </div>

              <div class="form-group">
                  <label for="tamano">Tamaño</label>
                  <select id="tamano" name="tamano" class="form-control">
                    
                    <?php $__currentLoopData = $rpt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rtrp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($rtrp->id); ?>"><?php echo e($rtrp->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>

              <div class="form-group">
              <?php $__currentLoopData = $rptep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rtrp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="form-check">
                         <input
                         "form-check-input"
                         type="checkbox"
                         name="temperamentos[]"
                         value="<?php echo e($rtrp->id); ?>"
                        />
                       <label class="form-check-label"><?php echo e($rtrp->nombre); ?></label>
                 </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </div>

              <div class="form-group">
                  <label for="alturaInicial">Altura Mínima</label>
                  <input
                  type="number"
                  class="form-control"
                  id="alturaInicial"
                  name="alturaInicial">
              </div>
              <div class="form-group">
                  <label for="alturaFinal">Altura Máxima</label>
                  <input
                  type="number"
                  class="form-control"
                  id="alturaFinal"
                  name="alturaFinal">
              </div>

              <?php echo csrf_field(); ?>

                <button type="submit" class="btn btn-primary">Guardar</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>