<?php $__env->startSection('contenido'); ?>
<?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('rest.create')); ?>" method="post">
              <br/><br/>
              <div class="form-group">
                  <label for="nombre">Nombre</label>
                  <input
                  type="text"
                  class="form-control"
                  id="nombre"
                  name="nombre">
              </div>
              <div class="form-group">
                  <label for="content">Provincia</label>
                  <input
                  type="text"
                  class="form-control"
                  id="provincia"
                  name="provincia">
              </div>


              <div class="form-group">
              <?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $esp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="form-check">
                         <input
                         "form-check-input"
                         type="checkbox"
                         name="especialidades[]"
                         value="<?php echo e($esp->id); ?>"
                        />
                       <label class="form-check-label"><?php echo e($esp->nombre); ?></label>
                 </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </div>

              <div class="form-group">
                <div class="row">
                  <label for="alturaInicial">Precios entre</label>
                    <div class="col">
                      <input
                      type="number"
                      class="form-control"
                      id="precioBajo"
                      name="precioBajo">
                    </div>
                    y
                    <div class="col">
                      <input
                      type="number"
                      class="form-control"
                      id="precioAlto"
                      name="precioAlto">
                    </div>
                </div>
              </div>

              <?php echo csrf_field(); ?>

                <button type="submit" class="btn btn-success">Guardar</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>