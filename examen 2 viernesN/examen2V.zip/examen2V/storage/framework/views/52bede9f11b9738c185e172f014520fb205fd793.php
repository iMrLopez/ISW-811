<?php $__env->startSection('contenido'); ?>
<?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-12">

            <form action="<?php echo e(route('helado.update')); ?>" method="post">
              <br/><br/>
              <div class="form-group">
                  <label for="nombre">Nombre</label>
                  <input
                  type="text"
                  class="form-control"
                  id="nombre"
                  name="nombre"
                  value="<?php echo e($elemento->nombre); ?>">
              </div>
              <div class="form-group">
                  <label for="content">Detalle</label>

                  <textarea
                  class="form-control"
                  id="detalle"
                  name="detalle"><?php echo e($elemento->detalle); ?></textarea>
              </div>
              <div class="form-group">
                  <label for="nombre">Preciop Unitario</label>
                  <input
                  type="number"
                  class="form-control"
                  id="precioUnitario"
                  name="precioUnitario"
                  value="<?php echo e($elemento->precioUnitario); ?>">
              </div>

              <div class="form-group">
              <?php $__currentLoopData = $caracteristicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="form-check">
                         <input
                         "form-check-input"
                         type="checkbox"
                         name="caracteristicas[]"
                         value="<?php echo e($cat->id); ?>"
                         <?php echo e($elemento->caracteristicas->contains($cat->id) ? 'checked' : ''); ?>

                        />
                       <label class="form-check-label"><?php echo e($cat->nombre); ?></label>
                 </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </div>
              <?php echo csrf_field(); ?>
              <input
              type="hidden"
              id="id"
              name="id"
              value="<?php echo e($elemento->id); ?>">
                <button type="submit" class="btn btn-success">Guardar</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>