<?php $__env->startSection('contenido'); ?>
  <?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('admin.update')); ?>" method="post">
                <div class="form-group">
                    <label for="nombre">Nombre</label>
                    <input
                    type="text"
                    class="form-control"
                    id="nombre"
                    name="nombre"
                    value="<?php echo e($vj->nombre); ?>">
                </div>
                <div class="form-group">
                    <label for="content">Descripción</label>
                    <textarea
                    class="form-control"
                    id="descripcion"
                    name="descripcion"><?php echo e($vj->descripcion); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="content">Fecha de Estreno Inicial</label>
                    <input
                    type="date"
                    class="form-control"
                    id="fechaEstrenoInicial"
                    name="fechaEstrenoInicial"
                    value="<?php echo e($vj->fechaEstrenoInicial); ?>">
                </div>
                <div class="form-group">
                <?php $__currentLoopData = $plataformas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plataforma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check">
                           <input
                           class="form-check-input" type="checkbox"
                           name="plataformas[]"
                           value="<?php echo e($plataforma->id); ?>"
                           <?php echo e($vj->plataformas->contains($plataforma->id) ? 'checked' : ''); ?>

                           />
                         <label class="form-check-label"><?php echo e($plataforma->nombre); ?></label>
                   </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
                <input type="hidden" name="id" value="<?php echo e($vjId); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary">Guardar</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>