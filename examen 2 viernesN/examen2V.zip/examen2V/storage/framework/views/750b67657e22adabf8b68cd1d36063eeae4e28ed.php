<?php $__env->startSection('titulo', 'Informacion Raza Perros'); ?>
<?php $__env->startSection('contenido'); ?>
  <blockquote class="blockquote">
      <h1 class="display-3"><?php echo e($rp->nombre); ?></h1>
      <p class="lead"><?php echo e($rp->descripcion); ?></p>

        <p class="lead">
          <b>Tamaño: </b> <?php echo e($rp->tamanos->nombre); ?>

        </p>
       <p class="lead">
          <b>Altura: </b> <?php echo e($rp->alturaInicial); ?>cm - <?php echo e($rp->alturaFinal); ?>cm
        </p>
        <p class="lead">
           <b>Temperamentos:</b>

        <ul class="list-group list-group-flush">
          <?php $__currentLoopData = $rp->temperamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="list-group-item">
                <?php echo e($temp->nombre); ?>

              </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </p>
  </blockquote>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>