<?php $__env->startSection('titulo', 'Informacion Raza Perros'); ?>
<?php $__env->startSection('contenido'); ?>
  <div class="jumbotron">

      <h1 class="display-3"><?php echo e($elemento->nombre); ?></h1>
      <div class="btn-group" role="group" aria-label="Basic example">
          <b>Votar:</b>
        <a class="btn btn-info" href="<?php echo e(route('rest.votar', ['id' => $elemento->id,'cantidad' =>1])); ?>">+1</a>
      <a class="btn btn-info" href="<?php echo e(route('rest.votar', ['id' => $elemento->id,'cantidad' =>2])); ?>">+2</a>
      <a class="btn btn-info" href="<?php echo e(route('rest.votar', ['id' => $elemento->id,'cantidad' =>3])); ?>">+3</a>

      </div>

    <p class="mb-1"><b>Provincia: </b><?php echo e($elemento->provincia); ?></p>
    <p class="mb-1"><b>Precios entre: </b> <?php echo e($elemento->precioBajo); ?> a <?php echo e($elemento->precioAlto); ?> colones</p>
    <p class="mb-1"><b>Especialidades: </b>
      <ul>
      <?php $__currentLoopData = $elemento->especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $esp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($esp->nombre); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    </p>
    <div class="alert alert-dismissible alert-primary">
      <h4 class="alert-heading">Sumatoria de Votos: <?php echo e($elemento->votos->sum('cantidad')); ?></h4>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>