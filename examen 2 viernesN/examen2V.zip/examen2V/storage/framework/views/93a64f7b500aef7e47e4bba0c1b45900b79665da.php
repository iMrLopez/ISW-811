<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?php echo e(route('rest.index')); ?>">Restaurantes</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarColor01">
      <ul class="navbar-nav mr-auto">
      <li class="nav-item ">
        <a class="nav-link" href="<?php echo e(route('rest.index')); ?>">Listado de Restaurantes</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="<?php echo e(route('rest.create')); ?>">Nuevo Restaurante</a>
      </li>

    </ul>
  </div>
</nav>
