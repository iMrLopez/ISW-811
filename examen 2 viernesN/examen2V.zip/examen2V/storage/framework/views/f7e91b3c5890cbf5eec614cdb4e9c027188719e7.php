<?php $__env->startSection('titulo', 'Información Video Juego'); ?>
<?php $__env->startSection('contenido'); ?>
  <div class="jumbotron">
    <h1 class="display-3"><?php echo e($vj->nombre); ?></h1>
    <span class="badge badge-dark"><?php echo e(count($vj->likes)); ?> Likes |
      <a href="<?php echo e(route('vj.videojuego.like', ['id' => $vj->id])); ?>">Like</a></p>
    </span>
    <p class="lead"><?php echo e($vj->descripcion); ?></p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>