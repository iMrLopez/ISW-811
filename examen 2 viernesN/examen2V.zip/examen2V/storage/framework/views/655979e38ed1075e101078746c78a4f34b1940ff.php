<?php $__env->startSection('titulo','Lista de VideoJuegos'); ?>
<?php $__env->startSection('contenido'); ?>
<div class="row">
<div class="col-lg-12">
<h2>Lista de Temperamentos de Razas de Perros</h2>
</div>
</div>
<br>
<div class="row">
  <div class="col-4">
    <div class="list-group" id="list-tab" role="tablist">
       <a class="list-group-item list-group-item-action active"  data-toggle="list" href="<?php echo e(route('rp.temperamentos')); ?>" role="tab">Temperamentos</a>
      <?php $__currentLoopData = $temperamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

       <a class="list-group-item list-group-item-action "
       href="<?php echo e(route('rp.temperamentos',['id'=>$temp->id])); ?>">
       <?php echo e($temp->nombre); ?></a>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
  <div class="col-8">
    <?php if(isset($tempRz->razaperros)): ?>
      <?php $__currentLoopData = $tempRz->razaperros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $razaPerro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <li><span style="font-weight:bold; font-size:25px">
              <?php echo e($razaPerro->nombre); ?></span></li>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

  </div>
</div>
<div class="row">
  <ul>

  </ul>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>