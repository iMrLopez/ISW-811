<?php $__env->startSection('contenido'); ?>
<?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('admin.update')); ?>" method="post">
              <br/><br/>
              <div class="form-group">
                  <label for="nombre">Nombre</label>
                  <input
                  type="text"
                  class="form-control"
                  id="nombre"
                  name="nombre" value="<?php echo e($rp->nombre); ?>">
              </div>
              <div class="form-group">
                  <label for="content">Descripción</label>
                  <textarea
                  class="form-control"
                  id="descripcion"
                  name="descripcion"><?php echo e($rp->descripcion); ?></textarea>
              </div>

              <div class="form-group">
                  <label for="tamano">Tamaño</label>

                  <select id="tamano" name="tamano" class="form-control">
                    
                    <?php $__currentLoopData = $tamano; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($tam->id); ?>" class="" name="tamanos"
                      <?php echo e(($rp->tamano_id===$tam->id) ? ' selected' : ' '); ?>>
                     <?php echo e($tam->nombre); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>


              <div class="form-group">
              <?php $__currentLoopData = $temperamento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="form-check">
                         <input
                         "form-check-input"
                         type="checkbox"
                         name="temperamentos[]"
                         value="<?php echo e($temp->id); ?>"
<?php echo e($rp->temperamentos->contains($temp->id) ? 'checked' : ''); ?>

                        />
                       <label class="form-check-label"><?php echo e($temp->nombre); ?></label>
                 </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </div>



              <div class="form-group">
                  <label for="alturaInicial">Altura Mínima</label>
                  <input
                  type="number"
                  class="form-control"
                  id="alturaInicial"
                  name="alturaInicial"
                  value="<?php echo e($rp->alturaInicial); ?>">
              </div>
              <div class="form-group">
                  <label for="alturaFinal">Altura Máxima</label>
                  <input
                  type="number"
                  class="form-control"
                  id="alturaFinal"
                  name="alturaFinal"
                  value="<?php echo e($rp->alturaFinal); ?>">
              </div>
              <input type='hidden' name="id" value="<?php echo e($rp->id); ?>">
              <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary">Guardar</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>