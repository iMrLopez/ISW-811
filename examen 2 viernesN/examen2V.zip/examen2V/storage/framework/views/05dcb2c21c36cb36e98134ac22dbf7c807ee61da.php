<?php $__env->startSection('title', 'Lista de VideoJuegos'); ?>

<?php $__env->startSection('content'); ?>
<!--  <div class="row">
    <div class="col-lg-12">
      <h1>Estructuras de control</h1>
    
    </div>
  </div>  -->
  <div class="row">
    <div class="col-lg-12">
      <h2>Lista de VideoJuegos</h2>
  </div>
</div>
  <div class="row">
    <div class="col">
      <div class="card" style="width: 18rem;">
        <div class="card-body">
          <h5 class="card-title">Super Mario Odyssey</h5>
          <p class="card-text">
            Es un videojuego de plataformas de mundo abierto para Nintendo Switch.</p>
          <a href="#" class="btn btn-primary">Ver</a>
        </div>
      </div>
   </div>
   <div class="col">
  <div class="card" style="width: 18rem;">
    <div class="card-body">
      <h5 class="card-title">Crash Bandicoot</h5>
      <p class="card-text">
        Es un videojuego de plataformas creado por Naughty Dog para la videoconsola PlayStation.</p>
      <a href="#" class="btn btn-primary">Ver</a>
    </div>
  </div>
</div>
<div class="col">
  <div class="card" style="width: 18rem;">
    <div class="card-body">
      <h5 class="card-title">The Legend of Zelda: Breath of the Wild</h5>
      <p class="card-text">
      Un mundo de aventuras, exploración y descubrimientos</p>
      <a href="#" class="btn btn-primary">Ver</a>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>