<?php $__env->startSection('contenido'); ?>

<div class="row">
<div class="col-lg-12">
<h2>Lista de Restaurantes</h2>
</div>
</div>
<div class="row">
  <div class="col-3">
    <div class="list-group">
        <?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $esp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a  href="<?php echo e(route('rest.especialidad',['id'=> $esp->id])); ?>"
            class="list-group-item list-group-item-action" >
            <?php echo e($esp->nombre); ?>

          </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
  <div class="col-9">
    <div class="row">
      <?php $__currentLoopData = $listado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $elemento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col">
        <div class="card" style="width: 18rem;">
          <div class="card-body">
            <h5 class="card-title"><?php echo e($elemento->nombre); ?></h5>
            <p class="card-text">
            <b>Provincia: </b><?php echo e($elemento->provincia); ?></p>
            <p class="card-text">
            <b>Cantidad de Votos: </b><?php echo e(count($elemento->votos)); ?></p>
            <a href="<?php echo e(route('rest.detalle',['id'=>$elemento->id])); ?>" class="btn btn-info">Ver</a>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>