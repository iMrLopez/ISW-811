<?php $__env->startSection('titulo','Lista de VideoJuegos'); ?>
<?php $__env->startSection('contenido'); ?>

  <?php $__currentLoopData = $rp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $te): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <li><span style="font-weight:bold; font-size:25px"><?php echo e($te->nombre); ?></span></li>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>