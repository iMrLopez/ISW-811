<?php $__env->startSection('contenido'); ?>
<?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-12">

            <form action="<?php echo e(route('sushi.update')); ?>" method="post">
              <br/><br/>
              <div class="form-group">
                  <label for="nombre">Nombre</label>
                  <input
                  type="text"
                  class="form-control"
                  id="nombre"
                  name="nombre"
                  value="<?php echo e($elemento->nombre); ?>">
              </div>
              <div class="form-group">
                  <label for="content">Descripción</label>

                  <textarea
                  class="form-control"
                  id="descripcion"
                  name="descripcion"><?php echo e($elemento->descripcion); ?></textarea>
              </div>
              <div class="form-group">
                  <label for="nombre">Precio</label>
                  <input
                  type="number"
                  class="form-control"
                  id="precio"
                  name="precio"
                  value="<?php echo e($elemento->precio); ?>">
              </div>

              <div class="form-group">
              <?php $__currentLoopData = $contenidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="form-check">
                         <input
                         "form-check-input"
                         type="checkbox"
                         name="contenidos[]"
                         value="<?php echo e($cont->id); ?>"
                         <?php echo e($elemento->contenidos->contains($cont->id) ? 'checked' : ''); ?>

                        />
                       <label class="form-check-label"><?php echo e($cont->nombre); ?></label>
                 </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </div>
              <?php echo csrf_field(); ?>
              <input
              type="hidden"
              id="id"
              name="id"
              value="<?php echo e($elemento->id); ?>">
                <button type="submit" class="btn btn-success">Guardar</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>