<!-- Comentario HTML -->


<?php $__env->startSection('titulo','Lista de VideoJuegos'); ?>
<?php $__env->startSection('contenido'); ?>

<div class="row">
<div class="col-lg-12">
<h2>Lista de Raza de Perros</h2>
</div>
</div>
<div class="row">
  <?php $__currentLoopData = $razaPerros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col">
    <div class="card" style="width: 18rem;">
      <div class="card-body">
        <h5 class="card-title"><?php echo e($rp->nombre); ?></h5>
        <p class="card-text">
        <b>Descripción: </b><?php echo e($rp->descripcion); ?></p>
        <p class="card-text">
        <b>Tamaño: </b><?php echo e($rp->tamanos->nombre); ?></p>
        <a href="<?php echo e(route('rp.detalle',['id'=>$rp->id])); ?>" class="btn btn-secondary">Ver</a>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>