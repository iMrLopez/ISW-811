<?php $__env->startSection('titulo', 'Lista de VideoJuegos'); ?>

<?php $__env->startSection('contenido'); ?>
<!--  <div class="row">
    <div class="col-lg-12">
      <h1>Estructuras de control</h1>
    
    </div>
  </div>  -->
  <div class="row">
    <div class="col-lg-12">
      <h2>Lista de VideoJuegos</h2>
  </div>
</div>
  <div class="row">
    <?php $__currentLoopData = $videojuegos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col col-lg-4">
        <div class="card" style="width: 18rem;">
          <div class="card-body">
            <h5 class="card-title"><?php echo e($vj->nombre); ?></h5>
            <p class="card-text">
              <?php echo e($vj['descripcion']); ?></p>
              <p class="card-text">
                  <?php $__currentLoopData = $vj->plataformas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plataforma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="badge badge-pill badge-info"><?php echo e($plataforma->nombre); ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </p>
            <a href="<?php echo e(route('vj.videojuego', ['id' => $vj->id])); ?>" class="btn btn-primary">Ver</a>
          </div>
        </div>
     </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>