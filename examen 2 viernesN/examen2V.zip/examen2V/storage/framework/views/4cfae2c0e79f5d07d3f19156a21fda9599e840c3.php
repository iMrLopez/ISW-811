<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <a class="navbar-brand" href="<?php echo e(route('helado.index')); ?>">Helados</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarColor01">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a href="<?php echo e(route('caracteristica.index')); ?>" class="nav-link">Características</a>
        </li>
        <li class="nav-item">
          <a href="<?php echo e(route('helado.pdf')); ?>" class="nav-link">PDF Helados</a>
        </li>
        <li class="nav-item">
          <a href="<?php echo e(route('helado.create')); ?>" class="nav-link">Nuevo Helado</a>
        </li>
        <li class="nav-item">
          <a href="<?php echo e(route('helado.grafico')); ?>" class="nav-link">Grafico Helados</a>
        </li>
    </ul>
    <ul class="navbar-nav ml-auto">
          <!-- Authentication Links -->
          <?php if(auth()->guard()->guest()): ?>
              <li><a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a></li>
            <li><a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Registrar')); ?></a></li>
        <?php else: ?>
          <li class="nav-link"><?php echo e(Auth::user()->name); ?></li>
          <li>
          <a class="nav-link" href="<?php echo e(route('logout')); ?>"
             onclick="event.preventDefault();
                           document.getElementById('logout-form').submit();">
              <?php echo e(__('Logout')); ?>

          </a>

          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo csrf_field(); ?>
          </form>
          </li>

          <?php endif; ?>
      </ul>
    </div>
  </nav>
