<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('', [
  'uses'=>'HeladoController@getIndex',
  'as'=>'admin.index'
]
);
//Admin
Route::group(['prefix'=>'admin'], function(){
  Route::get('', [
    'uses'=>'HeladoController@getIndex',
    'as'=>'helado.index'
  ]
  );
  Route::get('votar/{id}/{cantidad}',
  [
    'uses'=>'HeladoController@getVotar',
    'as'=>'helado.votar'
  ]
  );
  Route::get('create',
  [
    'uses'=>'HeladoController@getCrear',
    'as'=>'helado.create'
  ]);
  Route::get('edit/{id}',
  [
    'uses'=>'HeladoController@getEditar',
    'as'=>'helado.editar'
  ]
  );
  Route::post('create',
  [
      'uses' => 'HeladoController@postInsert',
      'as' => 'helado.insert'
  ]
  );
  Route::post('edit',
  [
    'uses'=>'HeladoController@postUpdate',
    'as'=>'helado.update'
  ]
  );
  Route::get('grafico', [
      'uses' => 'HeladoController@grafico',
      'as' => 'helado.grafico'
  ]);
  Route::get('pdf',
  [
    'uses'=>'HeladoController@descargarPDF',
    'as'=>'helado.pdf'
  ]);
  Route::get('caracteristica',
  [
      'uses' => 'CaracteristicaController@index',
      'as' => 'caracteristica.index'
  ]
  );
  Route::post('update-caracteristica',
  [
      'uses' => 'CaracteristicaController@update',
      'as' => 'update.caracteristica'
  ]
  );
});

Auth::routes();
