@extends('layouts.master')
@section('contenido')

  <div class="row justify-content-md-center">

      <div class="col-md-12">
        <h1>Sumatoria de Votos por Helado</h1>

    </div>

</div>

@endsection
