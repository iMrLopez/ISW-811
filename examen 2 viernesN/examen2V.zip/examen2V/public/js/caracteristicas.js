// Funcion detalle
$(document).on('click', '.ver-detalle', function() {
$('#ver').modal('show');
$('#identificador').text($(this).data('id'));
$('#nomb').text($(this).data('nombre'));
$('#detalle').text($(this).data('detalle'));
});
// Funcion editar Mostrar
$(document).on('click', '', function() {;

});
// Funcion editar

$('.modal-footer').on('click', '', function() {

  $.ajax({
    type: 'post',
    url: '',
    data: {

},
success: function(data) {

            $('.caracteristica').replaceWith(" "+
            "<tr class='caracteristica'>"+
            "<td></td>"+
            "<td></td>"+
             "<td>"+
             "<button class='ver-detalle btn btn btn-outline-info' data-id='' data-nombre='' data-detalle=''>"+
             "<img src='' class='ico' alt='Editar' />"+
             "</button>"+
             "<button class='editC btn btn btn-outline-warning' data-id='' data-nombre='' data-detalle=''>"+
             "<img src='' class='ico' alt='Editar' />"+
             "</button>"+
             "</td>"+
            "</tr>");
    }
  });
});
