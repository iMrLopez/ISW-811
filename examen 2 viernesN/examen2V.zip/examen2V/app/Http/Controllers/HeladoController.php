<?php

namespace App\Http\Controllers;

use App\Helado;
use App\Voto;
use App\Caracteristica;

use Illuminate\Http\Request;

class HeladoController extends Controller
{
    public function getIndex(){
      $caracteristicas=Caracteristica::all();
      $listado = Helado::orderBy('precioUnitario', 'desc')->get();
      return view('helado.index',['caracteristicas'=>$caracteristicas,'listado'=>$listado]);
    }

    public function getVotar($id,$puntos)
  {
      $helado = Helado::where('id', $id)->first();
      $punto = new Voto();
      $punto->puntos=$puntos;
      $helado->votos()->save($punto);
      return redirect()->back();
  }
  public function getCrear()
  {
      $caracteristicas = Caracteristica::all();
      return view('helado.create', [
        'caracteristicas' => $caracteristicas]);
  }
    public function getEditar($id)
    {
        $helado = Helado::where('id', $id)->with('votos')->first();
        $caracteristicas = Caracteristica::all();
        return view('helado.edit', [
          'elemento' => $helado,
          'caracteristicas' => $caracteristicas]);
    }
    public function postInsert( Request $request)
    {
      $this->validate($request, [
          'nombre' => 'required|min:2',
          'detalle' => 'required|min:3',
          'precioUnitario' => 'required|numeric'
      ]);

      $helado= new Helado();
      $helado->nombre= $request->input('nombre');
      $helado->detalle = $request->input('detalle');
      $helado->precioUnitario = $request->input('precioUnitario');

        $helado->save();
        $helado->caracteristicas()->
        attach($request->input('caracteristicas') === null ? [] :
           $request->input('caracteristicas'));
        return redirect()
        ->route('helado.index')
        ->with('info', 'Helado: ' . $request->input('nombre').' creado');
    }
    public function postUpdate(Helado $hel, Request $request)
    {
      $this->validate($request, [
          'nombre' => 'required|min:2',
          'detalle' => 'required|min:3',
          'precioUnitario' => 'required|numeric'
      ]);
      $helado = Helado::find($request->input('id'));
      $helado->nombre= $request->input('nombre');
      $helado->detalle = $request->input('detalle');
      $helado->precioUnitario = $request->input('precioUnitario');

        $helado->save();
        $helado->caracteristicas()->
        sync($request->input('caracteristicas') === null ? [] :
           $request->input('caracteristicas'));
        return redirect()
        ->route('helado.index')
        ->with('info', 'Helado: ' . $request->input('nombre').' creado');
    }
    public function grafico()
    {

    }
    public function descargarPDF(){
  
    }
  }
